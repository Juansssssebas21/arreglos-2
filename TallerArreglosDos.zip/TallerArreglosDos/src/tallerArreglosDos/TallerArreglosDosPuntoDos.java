package tallerArreglosDos;

public class TallerArreglosDosPuntoDos {
public static void main(String[] args) {
	int [] [] Numeros = { { 1,2,3,4,5,6,7,8,9,10}, {1,2,3} };
}
}
