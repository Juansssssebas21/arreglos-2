package tallerArreglosDos;

public class TallerArreglosDosPuntoTres {
public static void main(String[] args) {
	int  [] [] Numeross = { { 5,5,5,5}, {5,5,5} };
}
}
