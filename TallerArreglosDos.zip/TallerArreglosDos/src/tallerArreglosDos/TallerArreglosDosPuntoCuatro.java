package tallerArreglosDos;

public class TallerArreglosDosPuntoCuatro {
public static void main(String[] args) {
	int[] Tarea = { 1,1,1,1,1,1,1,1,1,1};
	
}
}
