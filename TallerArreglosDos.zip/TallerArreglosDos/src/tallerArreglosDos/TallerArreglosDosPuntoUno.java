package tallerArreglosDos;

public class TallerArreglosDosPuntoUno {
public static void main(String[] args) {
	int[] PuntoUno ;
	PuntoUno = new int [9];
}
}
